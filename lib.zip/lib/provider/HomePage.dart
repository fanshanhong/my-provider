

import 'package:flutter/material.dart';
import 'package:my_provider/provider/CountModel.dart';
import 'package:my_provider/provider/GoodsListScreen.dart';
import 'package:my_provider/provider/SecondPage.dart';
import 'package:provider/provider.dart';

class HomePage extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return HomeState();
  }

}

class HomeState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {

    final _counter = Provider.of<CountModel>(context);
    final textSize = Provider.of<int>(context).toDouble();

    print('全部rebuild');

    return Scaffold(
      floatingActionButton: RaisedButton(
        child: Text('+'),
        onPressed: (){
          Navigator.of(context).push(new MaterialPageRoute(builder: (context){
          //  return new GoodsListScreen();
            return new SecondPage();
          }));
        },
      ),
      body: Column(
        children: <Widget>[
          SizedBox(height: 60,),
          Text('${_counter.count}', style: TextStyle(fontSize: textSize),)
        ],
      ),
    );
  }

}