import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

// Selector 的使用

//  class Selector<A, S> extends Selector0<S> {
//  Selector({
//    Key key,
//    @required ValueWidgetBuilder<S> builder,
//    @required S Function(BuildContext, A) selector,
//    ShouldRebuild<S> shouldRebuild,
//    Widget child,
//  })  : assert(selector != null),
//        super(
//          key: key,
//          shouldRebuild: shouldRebuild,
//          builder: builder,
//          selector: (context) => selector(context, Provider.of(context)),
//          child: child,
//        );
//}

class GoodsListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    ListenableProvider listenableProvider;
    ChangeNotifierProvider  changeNotifierProvider;
    ValueListenableProvider valueListenableProvider;

    return Scaffold(
      body: ChangeNotifierProvider(
        create: (_) => GoodsListProvider(),
        child: Selector<GoodsListProvider, GoodsListProvider>( // A S
          //  A 是我们从顶层获取的 Provider 的类型
          //  S 是我们关心的具体类型，也即是获取到的 Provider 中真正对我们有用的类型，需要在 selector 中返回该类型。这个 Selector 的刷新范围也从整个 Provider 变成了 S
          shouldRebuild: (pre, next) => false,
          selector: (context, provider) => provider,
          builder: (context, provider, child) {
            return ListView.builder(
              itemCount: provider.total,
              itemBuilder: (context, index) {
                return Selector<GoodsListProvider, Goods>(
                  selector: (context, provider) => provider.goodsList[index],
                  builder: (context, data, child) {
                    print(('No.${index + 1} rebuild'));

                    return ListTile(
                      title: Text(data.goodsName),
                      trailing: GestureDetector(
                        onTap: () => provider.collect(index),
                        child: Icon(data.isCollection ? Icons.star : Icons.star_border),
                      ),
                    );
                  },
                );
              },
            );
          },
        ),
      ),
    );
  }
}

class GoodsListProvider with ChangeNotifier {
  List<Goods> _goodsList = List.generate(10, (index) => Goods(false, 'Goods No. $index'));

  get goodsList => _goodsList;

  get total => _goodsList.length;

  collect(int index) {
    var good = _goodsList[index];
    _goodsList[index] = Goods(!good.isCollection, good.goodsName);
    notifyListeners();
  }
}

class Goods {
  bool isCollection;
  String goodsName;

  Goods(this.isCollection, this.goodsName);
}
