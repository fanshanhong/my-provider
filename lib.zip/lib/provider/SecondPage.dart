import 'package:flutter/material.dart';
import 'package:my_provider/provider/CountModel.dart';
import 'package:provider/provider.dart';

class SecondPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return SecondState();
  }
}

class SecondState extends State<SecondPage> {
  @override
  Widget build(BuildContext context) {
    Icon icon = Icon(Icons.adb);
    return Scaffold(
      // Provider.of<T>(context) 将会把调用了该方法的 context 作为听众，并在 notifyListeners 的时候通知其刷新。
      body: Column(
        children: <Widget>[
          Consumer2(
            builder: (BuildContext context, CountModel countModel, int textSize, Widget child) {
              if(child == null) {
                print('child is null');
              }

              return Center(
                child: Text(
                  'Value: ${countModel.count}',
                  style: TextStyle(
                    fontSize: textSize.toDouble(),
                  ),
                ),
              );
            },
          ),
          MyTestWidget()
        ],
      ),
      floatingActionButton: Consumer(
        builder: (context, CountModel countModel, child) {
          return FloatingActionButton(
            onPressed: () {
              countModel.increment();
            },
            child: child,
          );
        },
        child: icon,
      ),
      // 成功抽离出 Consumer 中不变的部分，也就是浮动按钮中心的 Icon 并将其作为 child 参数传入 builder 方法中。
      // 如果child 不写,  则传入 Consumer 的 build 中的child 就是 null
    );
  }
}

class MyTestWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 100,
      height: 100,
      color: Colors.amberAccent,
    );
  }
}
