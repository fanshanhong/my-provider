import 'package:flutter/material.dart';

class ShareDataWidget extends InheritedWidget {
  int data;

  get datadata => data;

  get dataStr {
    return data;
  }

  ShareDataWidget({@required int data, Widget child}) : super(child: child) {
    this.data = data;

    print('ShareDataWidget构造方法被调用了');

  }

  static ShareDataWidget of(BuildContext buildContext) {
    return buildContext.dependOnInheritedWidgetOfExactType<ShareDataWidget>();
  }

  @override
  bool updateShouldNotify(ShareDataWidget oldWidget) {
    return oldWidget.datadata != data;
  }

  void setData(int i) {
    this.data = i;
  }
}
