import 'package:flutter/material.dart';
import 'package:flutter_app/share_date_widget.dart';
import 'package:flutter_app/test_widget.dart';

/// 页面
class InheritedPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _InheritedWidgetTestState();
  }
}

class _InheritedWidgetTestState extends State<InheritedPage> {
  int count = 0;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ShareDataWidget(
        //使用ShareDataWidget
        data: count,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(bottom: 20.0),
              child: TestWidget(), //子widget中依赖ShareDataWidget
            ),
//            MyButton(),
            RaisedButton(
              child: Text("计数增加"),
              onPressed: (){
                setState(() {
                  ++ count;
                });
              },
            )
          ],
        ),
      ),
    );
  }
}

class MyButton extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return MyButtonState();
  }
}

class MyButtonState extends State<MyButton> {

  @override
  Widget build(BuildContext context) {

    final inheritedContext = ShareDataWidget.of(context);

    return RaisedButton(

      child: Text(ShareDataWidget.of(context).data.toString(),style: Theme.of(context).textTheme.title,),
      //每点击一次，将count自增，然后重新build,ShareDataWidget的data将被更新
      onPressed: () {

        setState(() {
          print('111');
          inheritedContext.setData(100);
        });
//        print('sss:'+ShareDataWidget
//            .of(context)
//            .data
//            .toString());
      },
    );
  }
}
